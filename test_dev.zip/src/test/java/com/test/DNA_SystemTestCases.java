package com.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Observer;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

import com.dao.UserDao;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.main.MainAppController;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.model.Pets;
import com.model.User;
import com.service.UserService;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;

@RunWith(JUnit4.class)
public class DNA_SystemTestCases {

	private MockMvc mockMvc;

	@Rule
	public InstantTaskExecutorRule executorRule = new InstantTaskExecutorRule();

	private UserDao userRespository;
	private UserService userService;
	private Observer mockObserver;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.standaloneSetup(new MainAppController()).build();
		// setup view model with dependencies mocked
		userRespository = mock(UserDao.class);
		userService = mock(UserService.class);
		mockObserver = mock(Observer.class);
	}

	@Test
	public void verifyUserInsert() {
		User usr = new User("$admin", "$admin", "$admin");
		try {
			userRespository.saveUser(usr);
			userService.saveUser(usr);
			assertTrue(true);
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testUserInsertFailure() throws Exception {
		User usr = new User("dddddd22222222222222222222ddddfdfdfdfdfddddddddddddddddddddddddddd", "dadfdfdddddddddddddddddddddddddddddddd",
				"dadfdfddd1222222222ddddddddddddddddddddddddddddd");
		mockMvc.perform(post("/checkUser").contentType(MediaType.APPLICATION_JSON).content(asJsonString(usr)))
				.andExpect(redirectedUrl("/register"));
	}

	@Test
	public void testIndexPage() throws Exception {
		mockMvc.perform(get("/")).andExpect(status().isOk());
	}

	@Test
	public void testUsertReadFailure() throws Exception {
		User usr = new User("", "", "");
		mockMvc.perform(post("/checkUser").contentType(MediaType.APPLICATION_JSON).content(asJsonString(usr)))
				.andExpect(redirectedUrl("/login"));
	}

	@Test
	public void testInsertValidation() throws Exception {
		Pets pet = new Pets("dddddddddddddddddddddddddddddd", 100000, "ddddddddddddddddddddddddddddddd");
		mockMvc.perform(post("/savePet").contentType(MediaType.APPLICATION_JSON).content(asJsonString(pet)))
				.andExpect(redirectedUrl("/myPets"));
	}

	@Test
	public void testInsertFailure() throws Exception {
		try {
			userRespository.savePet(null);
			userService.savePet(null);
			assertTrue(true);
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testUserRead() throws Exception {
		User usr = new User("$admin", "$admin", "$admin");
		mockMvc.perform(post("/saveUser").contentType(MediaType.APPLICATION_JSON).content(asJsonString(usr)))
				.andExpect(redirectedUrl("/login"));
		mockMvc.perform(post("/checkUser").contentType(MediaType.APPLICATION_JSON).content(asJsonString(usr)))
				.andExpect(redirectedUrl("/home"));
	}

	@Test
	public void testUserInsert() throws Exception {
		User usr = new User("$admin$", "$admin$", "$admin$");
		mockMvc.perform(post("/save").contentType(MediaType.APPLICATION_JSON).content(asJsonString(usr)))
				.andExpect(redirectedUrl("/login"));
	}

	@Test
	public void testUserInsertValidation() throws Exception {
		User usr = new User("", "", "");
		mockMvc.perform(post("/saveUser").contentType(MediaType.APPLICATION_JSON).content(asJsonString(usr)))
				.andExpect(redirectedUrl("/register"));
	}

	@Test
	public void testGetAll() throws Exception {
		try {
			userRespository.home();
			userService.home();
			assertTrue(true);
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testInsert() throws Exception {
		Pets pet = new Pets("Star", 11, "CH");
		try {
			userRespository.savePet(pet);
			userService.savePet(pet);
			assertTrue(true);
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testUpdate() throws Exception {
		Pets pet = new Pets("Star", 11, "CH");
		try {
			userRespository.savePet(pet);
			userService.savePet(pet);
			assertTrue(true);
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testReadFailure() throws Exception {
		mockMvc.perform(get("/pets/{id}", 999).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound());
	}

	@Test
	public void testUpdateValidation() throws Exception {
		try {
			userRespository.savePet(null);
			userService.savePet(null);
			assertTrue(true);
		} catch (Exception e) {
			fail();
		}
	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
