package com.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Pets;
import com.model.User;

@Repository
public class UserDaoImpl implements UserDao {
	HttpServletRequest req = null;
	@Autowired
	SessionFactory sessionFactory;

	public void saveUser(User user) {
		try {
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			session.save(user);
			tx.commit();

		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public List<Pets> home() {
		try {
			return sessionFactory.openSession().createQuery("from Pets").getResultList();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return null;
	}

	public void savePet(Pets pets) {
		try {
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			// tx.begin();
			session.save(pets);
			tx.commit();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public Pets petList(int id) {
		try {
			return (Pets) sessionFactory.openSession().createQuery("from Pets where petId=" + id).uniqueResult();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return null;

	}

	public List<Pets> myPetList(int userId) {
		try {
			return sessionFactory.openSession().createQuery("from Pets where petownerid=" + userId).getResultList();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return null;

	}

	public User checkUser(String name, String passwd) {
		try {
			return (User) sessionFactory.openSession()
					.createQuery("from User where userName='" + name + "' and userPasswd='" + passwd + "'")
					.uniqueResult();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return null;
	}

	@Override
	public void buyPet(int petId, int userId) {
		try {
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			// tx.begin();
			Pets pet = petList(petId);
			pet.setUser((User) session.createQuery("from User where id=" + userId).uniqueResult());
			session.saveOrUpdate(pet);
			tx.commit();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
