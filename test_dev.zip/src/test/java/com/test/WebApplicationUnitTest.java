package com.test;

import static org.junit.Assert.fail;

import org.junit.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@AutoConfigureMockMvc
public class WebApplicationUnitTest {


	@Test
	public void login() throws Exception {
		fail();
	}
}
